class Motobomba {
    constructor(codigo) {
        this.codigo = codigo;
        this.bombero = [];

    }
}