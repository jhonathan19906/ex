class Bombero {
    constructor(nombre, anoNacimiento) {
        this.nombre = nombre;
        this.anoNacimiento = anoNacimiento;

    }
}